from django.contrib.auth.forms import UserCreationForm
from django import forms
from django import forms
from App1.models import book
class bookform(forms.ModelForm):
    class Meta:
        model=book
        fields='__all__'
