from django.urls import path

from . import views 

urlpatterns = [
   
   
    path('',views.home,name='home'),
    path('list/',views.list,name='list'),
    path('view_book/<int:p>',views.booklist,name="view_book"),
    path('edit_book/<int:p>',views.edit_book,name="edit_book"),
    path('delete_book/<int:p>',views.delete_book,name="delete_book"),


]