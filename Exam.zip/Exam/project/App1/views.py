from django.shortcuts import render
from .models import *
from .forms import *


# Create your views here.

def home(request):
    return render(request,'home.html')

def list(request):
    return render(request,'list.html')

def booklist(request):
    b=book.objects.all()
    return render(request,'list.html',{'b':b})

def edit_book(request,p):
    b=book.objects.get(pk=p)
    form = bookform(instance=b)
    if (request.method == "POST"):
        form = form(request.POST,request.FILES,instance=b)
        if (form.is_valid()):
            form.save()
            return home(request)
    return render(request, 'upload.html', {'form': form})

def delete_book(request,p):
    b=book.objects.get(pk=p)
    b.delete()
    return booklist(request)